<?php
	$menubilgi = array(
		"icon" => '<i class="la la-smile"></i>',
		"adi" => 'Başarı Hikayeleri',
		"sql" => 'ekip_referans',
		"altlink" => array(
			"0" => array("adi"=>"Başarı Hikayesi Ekle","link"=>"referans_ekle"),
			"1" => array("adi"=>"Başarı Hikayeleri Listele","link"=>"referans_listele")
		)
	)
?>