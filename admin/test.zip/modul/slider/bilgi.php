<?php
	$menubilgi = array(
		"icon" => '<i class="la la-files-o"></i>',
		"adi" => 'Slider',
		"sql" => 'ekip_slider',
		"altlink" => array(
			"0" => array("adi"=>"Slider Ekle","link"=>"slider_ekle"),
			"1" => array("adi"=>"Slider Listele","link"=>"slider_listele")
		)
	)
?>