<?php
	$menubilgi = array(
		"icon" => '<i class="la la-question"></i>',
		"adi" => 'Hesap Numaraları',
		"sql" => 'ekip_hesapnumaralari',
		"altlink" => array(
			"0" => array("adi"=>"Hesap Numarası Ekle","link"=>"hesapnumaralari_ekle"),
			"1" => array("adi"=>"Hesap Numarası Listele","link"=>"hesapnumaralari_listele")
		)
	)
?>