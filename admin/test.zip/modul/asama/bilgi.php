<?php
	$menubilgi = array(
		"icon" => '<i class="la la-question"></i>',
		"adi" => 'Aşama',
		"sql" => 'ekip_asama',
		"altlink" => array(
			"0" => array("adi"=>"Aşama Ekle","link"=>"asama_ekle"),
			"1" => array("adi"=>"Aşama Listele","link"=>"asama_listele")
		)
	)
?>