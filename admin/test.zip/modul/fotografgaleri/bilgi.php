<?php
	$menubilgi = array(
		"icon" => '<i class="la la-picture-o"></i>',
		"adi" => 'Before-After',
		"sql" => 'ekip_fotografgaleri',
		"altlink" => array(
			"0" => array("adi"=>"Before-After Ekle","link"=>"fotografgaleri_ekle"),
			"1" => array("adi"=>"Before-After Listele","link"=>"fotografgaleri_listele")
		)
	)
?>