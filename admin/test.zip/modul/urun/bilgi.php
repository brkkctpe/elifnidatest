<?php
	$menubilgi = array(
		"icon" => '<i class="la la-shopping-basket"></i>',
		"adi" => 'Ürünler',
		"sql" => 'ekip_urun',
		"altlink" => array(
			"0" => array("adi"=>"Ürün Ekle","link"=>"urun_ekle"),
			"1" => array("adi"=>"Ürün Listele","link"=>"urun_listele"),
			"2" => array("adi"=>"Kategoriler","link"=>"urunkategori_listele")
		)
	)
?>