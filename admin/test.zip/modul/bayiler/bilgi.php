<?php
	$menubilgi = array(
		"icon" => '<i class="la la-users"></i>',
		"adi" => 'Bayiler',
		"sql" => 'ekip_bayiler',
		"altlink" => array(
			"0" => array("adi"=>"Bayi Ekle","link"=>"bayiler_ekle"),
			"1" => array("adi"=>"Bayi Listele","link"=>"bayiler_listele")
		)
	)
?>