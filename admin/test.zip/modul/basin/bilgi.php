<?php
	$menubilgi = array(
		"icon" => '<i class="la la-smile"></i>',
		"adi" => 'Basın',
		"sql" => 'ekip_basin',
		"altlink" => array(
			"0" => array("adi"=>"Basın Ekle","link"=>"basin_ekle"),
			"1" => array("adi"=>"Basın Listele","link"=>"basin_listele")
		)
	)
?>