<?php
	$menubilgi = array(
		"icon" => '<i class="la la-smile"></i>',
		"adi" => 'Diyet Taslakları',
		"sql" => 'ekip_diyettaslak',
		"altlink" => array(
			"0" => array("adi"=>"Taslak Ekle","link"=>"diyettaslak_ekle"),
			"1" => array("adi"=>"Taslak Listele","link"=>"diyettaslak_listele")
		)
	)
?>