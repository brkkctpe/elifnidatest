<?php
	$menubilgi = array(
		"icon" => '<i class="la la-users"></i>',
		"adi" => 'Yetkili Satıcılar',
		"sql" => 'ekip_yetkilisatici',
		"altlink" => array(
			"0" => array("adi"=>"Yetkili Satıcı Ekle","link"=>"yetkilisatici_ekle"),
			"1" => array("adi"=>"Yetkili Satıcı Listele","link"=>"yetkilisatici_listele")
		)
	)
?>