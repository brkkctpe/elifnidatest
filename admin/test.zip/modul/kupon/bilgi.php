<?php
	$menubilgi = array(
		"icon" => '<i class="las la-money-check"></i>',
		"adi" => 'Kupon',
		"sql" => 'ekip_kupon',
		"altlink" => array(
			"0" => array("adi"=>"Kupon Ekle","link"=>"kupon_ekle"),
			"1" => array("adi"=>"Kupon Listele","link"=>"kupon_listele")
		)
	)
?>