<?php
	$menubilgi = array(
		"icon" => '<i class="la la-book-reader"></i>',
		"adi" => 'Seo Link',
		"sql" => 'ekip_seolink',
		"altlink" => array(
			"0" => array("adi"=>"Seo Link Ekle","link"=>"seolink_ekle"),
			"1" => array("adi"=>"Seo Link Listele","link"=>"seolink_listele")
		)
	)
?>