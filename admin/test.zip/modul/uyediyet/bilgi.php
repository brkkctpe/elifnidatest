<?php
	$menubilgi = array(
		"icon" => '<i class="la la-smile"></i>',
		"adi" => 'Üye Diyetleri',
		"sql" => 'ekip_uyediyet',
		"altlink" => array(
			"0" => array("adi"=>"Diyet Ekle","link"=>"uyediyet_ekle"),
			"1" => array("adi"=>"Diyet Listele","link"=>"uyediyet_listele")
		)
	)
?>