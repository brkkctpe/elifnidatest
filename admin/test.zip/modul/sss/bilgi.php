<?php
	$menubilgi = array(
		"icon" => '<i class="la la-question"></i>',
		"adi" => 'SSS',
		"sql" => 'ekip_sss',
		"altlink" => array(
			"0" => array("adi"=>"SSS Ekle","link"=>"sss_ekle"),
			"1" => array("adi"=>"SSS Listele","link"=>"sss_listele")
		)
	)
?>