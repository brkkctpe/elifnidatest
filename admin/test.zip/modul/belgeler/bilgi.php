<?php
	$menubilgi = array(
		"icon" => '<i class="la la-file-pdf"></i>',
		"adi" => 'Belgeler',
		"sql" => 'ekip_belgeler',
		"altlink" => array(
			"0" => array("adi"=>"Belge Ekle","link"=>"belgeler_ekle"),
			"1" => array("adi"=>"Belge Listele","link"=>"belgeler_listele")
		)
	)
?>