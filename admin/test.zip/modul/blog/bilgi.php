<?php
	$menubilgi = array(
		"icon" => '<i class="flaticon-book"></i>',
		"adi" => 'Blog',
		"sql" => 'ekip_blog',
		"altlink" => array(
			"0" => array("adi"=>"Blog Ekle","link"=>"blog_ekle"),
			"1" => array("adi"=>"Blog Listele","link"=>"blog_listele"),
			"2" => array("adi"=>"Kategoriler","link"=>"blogkategori_listele")
		)
	)
?>