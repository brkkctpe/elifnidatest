<?php
	$menubilgi = array(
		"icon" => '<i class="la la-book-reader"></i>',
		"adi" => 'Hizmetler',
		"sql" => 'ekip_hizmetler',
		"altlink" => array(
			"0" => array("adi"=>"Hizmet Ekle","link"=>"hizmetler_ekle"),
			"1" => array("adi"=>"Hizmet Listele","link"=>"hizmetler_listele")
		)
	)
?>