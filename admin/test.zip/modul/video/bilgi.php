<?php
	$menubilgi = array(
		"icon" => '<i class="la la-video"></i>',
		"adi" => 'Videolar',
		"sql" => 'ekip_video',
		"altlink" => array(
			"0" => array("adi"=>"Video Ekle","link"=>"video_ekle"),
			"1" => array("adi"=>"Video Listele","link"=>"video_listele"),
			"2" => array("adi"=>"Kategoriler","link"=>"videokategori_listele")
		)
	)
?>