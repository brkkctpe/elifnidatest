<?php
	$menubilgi = array(
		"icon" => '<i class="la la-smile"></i>',
		"adi" => 'Ödüller',
		"sql" => 'ekip_oduller',
		"altlink" => array(
			"0" => array("adi"=>"Ödül Ekle","link"=>"oduller_ekle"),
			"1" => array("adi"=>"Ödül Listele","link"=>"oduller_listele")
		)
	)
?>