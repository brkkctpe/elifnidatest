<?php
	$menubilgi = array(
		"icon" => '<i class="flaticon-book"></i>',
		"adi" => 'Hesap',
		"sql" => 'ekip_hesap',
		"altlink" => array(
			"0" => array("adi"=>"Hesap Ekle","link"=>"hesap_ekle"),
			"1" => array("adi"=>"Hesap Listele","link"=>"hesap_listele")
		)
	)
?>