<?php
$menubilgi["adi"]  = "Randevu Ekle";
$menubilgi["icon"] = '<i class="fas fa-calendar-plus"></i>';
$menubilgi["altlink"][] = array("link"=>"randevuekle", "adi"=>"Yeni Randevu Ekle");
?>
