<?php
	$menubilgi = array(
		"icon" => '<i class="la la-smile"></i>',
		"adi" => 'Ekibimiz',
		"sql" => 'ekip_partner',
		"altlink" => array(
			"0" => array("adi"=>"Ekip Ekle","link"=>"partner_ekle"),
			"1" => array("adi"=>"Ekip Listele","link"=>"partner_listele")
		)
	)
?>