<?php
	$menubilgi = array(
		"icon" => '<i class="la la-book-reader"></i>',
		"adi" => 'Tarifler',
		"sql" => 'ekip_tarifler',
		"altlink" => array(
			"0" => array("adi"=>"Tarif Ekle","link"=>"tarifler_ekle"),
			"1" => array("adi"=>"Tarif Listele","link"=>"tarifler_listele")
		)
	)
?>