<?php
	$menubilgi = array(
		"icon" => '<i class="la la-shapes"></i>',
		"adi" => 'Projeler',
		"sql" => 'ekip_proje',
		"altlink" => array(
			"0" => array("adi"=>"Proje Ekle","link"=>"proje_ekle"),
			"1" => array("adi"=>"Proje Listele","link"=>"proje_listele")
		)
	)
?>