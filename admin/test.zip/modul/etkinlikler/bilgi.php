<?php
	$menubilgi = array(
		"icon" => '<i class="la la-smile"></i>',
		"adi" => 'Etkinlikler',
		"sql" => 'ekip_etkinlikler',
		"altlink" => array(
			"0" => array("adi"=>"Etkinlik Ekle","link"=>"etkinlikler_ekle"),
			"1" => array("adi"=>"Etkinlikler Listele","link"=>"etkinlikler_listele")
		)
	)
?>