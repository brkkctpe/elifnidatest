<?php
	$menubilgi = array(
		"icon" => '<i class="la la-copyright"></i>',
		"adi" => 'Markalar',
		"sql" => 'ekip_markalar',
		"altlink" => array(
			"0" => array("adi"=>"Marka Ekle","link"=>"markalar_ekle"),
			"1" => array("adi"=>"Marka Listele","link"=>"markalar_listele")
		)
	)
?>