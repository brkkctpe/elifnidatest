<?php
	$menubilgi = array(
		"icon" => '<i class="flaticon-book"></i>',
		"adi" => '',
		"sql" => 'ekip_videokategori',
		"altlink" => array(
			"0" => array("adi"=>"Blog Ekle","link"=>"blog_ekle"),
			"1" => array("adi"=>"Blog Listele","link"=>"blog_listele")
		)
	)
?>